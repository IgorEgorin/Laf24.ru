package ru.laf24.test;

import com.codeborne.selenide.Configuration;
import com.codeborne.selenide.Selenide;
import io.github.bonigarcia.wdm.ChromeDriverManager;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;

import static com.codeborne.selenide.Selenide.sleep;

public class PrecondChrome extends OverAllPage {


    @Before
    public void before(){
        ChromeDriverManager.getInstance().setup();
        Configuration.browser ="Chrome";
        Configuration.timeout = 7000;
        Selenide.open("https://laf24.ru/catalog/oils");
    }

    @After
    public void after(){
        Selenide.close();
    }

}
