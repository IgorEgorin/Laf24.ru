package ru.laf24.test;

import com.codeborne.selenide.Selenide;
import com.codeborne.selenide.SelenideElement;

import static com.codeborne.selenide.Selectors.byText;
import static com.codeborne.selenide.Selenide.$;

public class BasketPage {

    private final SelenideElement buttonMakeOrder;
    private final SelenideElement buttonIncrease;
    private final SelenideElement buttonDecrease;
    private final SelenideElement hoverInsideBasket;

    public BasketPage() {
        this.buttonMakeOrder = $(byText("Оформить заказ"));
        this.buttonIncrease = $("[class=\"btn-plus material-icons \"]");
        this.buttonDecrease = $("[class=\"btn-minus material-icons \"]");
        this.hoverInsideBasket = $(byText("На складе уже сейчас"));
    }

    public SelenideElement getButtonMakeOrder() {
        return buttonMakeOrder;
    }

    public SelenideElement getButtonIncrease() {
        return buttonIncrease;
    }

    public SelenideElement getButtonDecrease() {
        return buttonDecrease;
    }

    public SelenideElement getHoverInsideBasket() {
        return hoverInsideBasket;
    }
}
