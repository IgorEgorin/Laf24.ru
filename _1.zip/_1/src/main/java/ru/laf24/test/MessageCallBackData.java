package ru.laf24.test;

public class MessageCallBackData {

    public String name;
    public String vinField;
    public String questionField;

    public MessageCallBackData(String name, String vinField, String questionField) {
        this.name = name;
        this.vinField = vinField;
        this.questionField = questionField;
    }

    @Override
    public  String toString() {
        return name+vinField+questionField;

    }
}
