package ru.laf24.test;

/**
 * Created by 1 on 26.01.2018.
 */
public class PriceData {

    public Integer priceOne;
    public Integer priceTwo;

    public PriceData(Integer priceOne, Integer priceTwo) {
        this.priceOne = priceOne;
        this.priceTwo = priceTwo;
    }

    @Override
    public String toString() {
        return String.valueOf(priceOne+priceTwo);
    }

}
