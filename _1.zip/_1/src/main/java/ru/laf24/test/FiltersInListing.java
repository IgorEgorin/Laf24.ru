package ru.laf24.test;

import com.codeborne.selenide.Selenide;
import com.codeborne.selenide.SelenideElement;

import static com.codeborne.selenide.Selectors.byText;
import static com.codeborne.selenide.Selenide.$;

public class FiltersInListing {



    private final SelenideElement elementfilter;
    private final SelenideElement filterBrand;
    private final SelenideElement filterTypeFluid;
    private final SelenideElement filterBrandShowAll;
    private final SelenideElement filterBrandSeries;
    private final SelenideElement viscocitySeries;
    private final SelenideElement composition;
    private final SelenideElement filterVolume;
    private final SelenideElement filterUsage;
    private final SelenideElement filterSpecificationAcea;
    private final SelenideElement filterSpecAceaDropDown;
    private final SelenideElement filterPrice;
    private final SelenideElement filterQuantity;
    private final SelenideElement filterQuantityField;
    private final SelenideElement chipsClose;

    private final SelenideElement chkBoxMobil;
    private final SelenideElement chkBoxMineralnoe;
    private final SelenideElement chkBoxPolusint;
    private final SelenideElement chkBoxSint;

    private final SelenideElement priceFilterFieldOne;
    private final SelenideElement priceFilterFieldOTwo;

    private final SelenideElement listMayTakeAway;
    private final SelenideElement chkBoxToday;
//    private final SelenideElement chkBoxTomorrow;
//    private final SelenideElement chkBoxDayAfterTomorrow;
//    private final SelenideElement chkBoxThreeFiveDays;
//    private final SelenideElement chkBoxMoreThanFive;
    private final SelenideElement listFilterStoreForPickUp;
//    private final SelenideElement linkFilterStoreStudencheskaya;
//    private final SelenideElement linkFilterSofiyskaya;
    private final SelenideElement linkFilterDalnVostoch;
//    private final SelenideElement linkFilterTorfinaya;
//    private final SelenideElement linkFilterShuhari;
//    private final SelenideElement linkFilterCosmonavtov;
//    private final SelenideElement linkFilterDnepropetrovskaya;
//    private final SelenideElement linkFilterSimonova;
//    private final SelenideElement linkFilterZhukova;
//    private final SelenideElement linkFilterUdelnaya;


    public FiltersInListing() {
        this.elementfilter = $("[class='filter indent-20']");
        this.filterBrand = elementfilter.$(byText("Бренд"));
        this.filterTypeFluid = elementfilter.$(byText("Тип жидкости"));
        this.filterBrandShowAll = $(byText("Показать все бренды"));
        this.filterBrandSeries = elementfilter.$(byText("Показать все бренды"));
        this.viscocitySeries = elementfilter.$(byText("Вязкость"));
        this.composition = elementfilter.$(byText("Состав"));
        this.filterVolume = elementfilter.$(byText("Объем"));
        this.filterUsage = elementfilter.$(byText("Применимость"));
        this.filterSpecificationAcea = elementfilter.$(byText("Спецификация ACEA"));
        this.filterSpecAceaDropDown = elementfilter.$("[class=\"select-dropdown\"]");
        this.filterPrice = elementfilter.$(byText("Цена"));
        this.filterQuantity = $(byText("Наличие"));
        this.filterQuantityField = elementfilter.$("#input_253");
        this.chipsClose = $("[class=\"chip__close\"]");
        this.chkBoxMobil = elementfilter.$(byText("Mobil"));
        this.chkBoxMineralnoe = elementfilter.$(byText("Минеральное"));
        this.chkBoxPolusint = elementfilter.$(byText("Полусинтетическое"));
        this.chkBoxSint = elementfilter.$(byText("Синтетическое"));
        this.priceFilterFieldOne = elementfilter.$("[name='price_1_min']");
        this.priceFilterFieldOTwo = elementfilter.$("[name='price_1_max']");
        this.listMayTakeAway = $(byText("Можно забрать"));
        this.chkBoxToday = $(byText("Сегодня"));
//        this.chkBoxTomorrow = Selenide.$(byText("Можно найти"));
//        this.chkBoxDayAfterTomorrow = Selenide.$(byText("Можно найти"));
//        this.chkBoxThreeFiveDays = Selenide.$(byText("Можно найти"));
//        this.chkBoxMoreThanFive = Selenide.$(byText("Можно найти"));
          this.listFilterStoreForPickUp = $("[value='Выберите магазин']");
          this.linkFilterDalnVostoch = $(byText("Дальневосточный"));

    }

    public SelenideElement getElementfilter() {
        return elementfilter;
    }

    public SelenideElement getFilterBrand() {
        return filterBrand;
    }

    public SelenideElement getFilterTypeFluid() {
        return filterTypeFluid;
    }

    public SelenideElement getFilterBrandShowAll() {
        return filterBrandShowAll;
    }

    public SelenideElement getFilterBrandSeries() {
        return filterBrandSeries;
    }

    public SelenideElement getViscocitySeries() {
        return viscocitySeries;
    }

    public SelenideElement getComposition() {
        return composition;
    }

    public SelenideElement getFilterVolume() {
        return filterVolume;
    }

    public SelenideElement getFilterUsage() {
        return filterUsage;
    }

    public SelenideElement getFilterSpecificationAcea() {
        return filterSpecificationAcea;
    }

    public SelenideElement getFilterSpecAceaDropDown() {
        return filterSpecAceaDropDown;
    }

    public SelenideElement getFilterPrice() {
        return filterPrice;
    }

    public SelenideElement getFilterQuantity() {
        return filterQuantity;
    }

    public SelenideElement getFilterQuantityField() {
        return filterQuantityField;
    }

    public SelenideElement getChipsClose() {
        return chipsClose;
    }

    public SelenideElement getChkBoxMobil() {
        return chkBoxMobil;
    }

    public SelenideElement getChkBoxMineralnoe() {
        return chkBoxMineralnoe;
    }

    public SelenideElement getChkBoxPolusint() {
        return chkBoxPolusint;
    }

    public SelenideElement getChkBoxSint() {
        return chkBoxSint;
    }

    public SelenideElement getPriceFilterFieldOne() {
        return priceFilterFieldOne;
    }

    public SelenideElement getPriceFilterFieldOTwo() {
        return priceFilterFieldOTwo;
    }

    public SelenideElement getLinkMayTake() {
        return listMayTakeAway;
    }

    public SelenideElement getChkBoxToday() {
        return chkBoxToday;
    }

//    public SelenideElement getChkBoxTomorrow() {
//        return chkBoxTomorrow;
//    }
//
//    public SelenideElement getChkBoxDayAfterTomorrow() {
//        return chkBoxDayAfterTomorrow;
//    }
//
//    public SelenideElement getChkBoxThreeFiveDays() {
//        return chkBoxThreeFiveDays;
//    }
//
//    public SelenideElement getChkBoxMoreThanFive() {
//        return chkBoxMoreThanFive;
//    }

    public SelenideElement getListFilterStoreForPickUp() {
        return listFilterStoreForPickUp;
    }

    public SelenideElement getLinkFilterDalnVostoch() {
        return linkFilterDalnVostoch;
    }


    public void selectDalnVosStore() {
        getChkBoxToday().click();
        getListFilterStoreForPickUp().click();
        getLinkFilterDalnVostoch().click();
    }
    public void selectMobil() {
        getFilterBrand().click();
        getFilterBrandShowAll().click();
        getChkBoxMobil().click();
    }

    public void enterPriceData(Integer priceOne,Integer priceTwo) {
        getPriceFilterFieldOne().setValue(String.valueOf(priceOne));
        getPriceFilterFieldOTwo().setValue(String.valueOf(priceTwo));
    }
}
