package ru.laf24.test;

import com.codeborne.selenide.ElementsCollection;
import com.codeborne.selenide.Selenide;
import com.codeborne.selenide.SelenideElement;

import java.util.Random;

import static com.codeborne.selenide.Selectors.byText;
import static com.codeborne.selenide.Selenide.*;


public class Listing {

    private final SelenideElement element;
    private final SelenideElement elementHoverCard;

    private final SelenideElement cardGoodsAll;
    private final SelenideElement priceInCardGoods;
    private final SelenideElement addToBasket;
    private final SelenideElement addToBasketFromCard;
    private final SelenideElement cardTitleOne;
    private final SelenideElement cardTextListing;
    private final SelenideElement cardTextInside;
    private final SelenideElement typeFluid;
    private final SelenideElement inStockTooltip;
    private final SelenideElement hoverAtStockNow;
    private final SelenideElement hoverAtStockNowInCard;
    private final SelenideElement buttonPaginator;

    Random random = new Random();
    ElementsCollection titleCollection = $$("[class='item-card__title']");
    ElementsCollection buttonAddBasCollection = $$("[class='btn waves-effect waves-light btn_buy-m offers__item__price__btn ']");
    ElementsCollection hoverListingCollection = $$("[class='item']");



    public Listing() {
        this.element = $("[class='section']");
        this.elementHoverCard = $("[class='section search-result-aside']");
        this.cardGoodsAll = $("[class='item-card__main']");
        this.priceInCardGoods = element.$("[class='real-price']");
        this.addToBasket = $("[class='btn waves-effect waves-light btn_buy-m offers__item__price__btn ']");
        this.addToBasketFromCard = $("[class='btn waves-effect waves-light btn_buy-m ']");
        this.inStockTooltip = element.$("[class='chip chip--bordered chip--bordered--green offer-state']");
        this.typeFluid = element.$("[class=\"description-fltr__item\"]");
        this.cardTitleOne = element.$("[class=\"title--name\"]");
        this.cardTextListing = element.$("[class=\"item__fltr-list\"]");
        this.cardTextInside = $("[class=\"indent-20 item__fltr-list\"]");
        this.hoverAtStockNow = element.$("[class='item']");
        this.hoverAtStockNowInCard = $("[class=\"search-result__state\"] [class=\"chips\"]");
        this.buttonPaginator = $("[class='pagination-upload']");
    }

    public SelenideElement getElement() {
        return element;
    }

    public SelenideElement getCardGoodsAll() {
        return cardGoodsAll;
    }

    public SelenideElement getHoverAtStockNow() {
        return hoverAtStockNow;
    }

    public SelenideElement getPriceInCardGoods() {
        return priceInCardGoods;
    }

    public SelenideElement getAddToBasket() {
        return addToBasket;
    }

    public SelenideElement getAddToBasketFromCard() {
        return addToBasketFromCard;
    }

    public SelenideElement getInStockTooltip() {
        return inStockTooltip;
    }

    public SelenideElement getTypeFluid() {
        return typeFluid;
    }

    public SelenideElement getCardTitleOne() {
        return cardTitleOne;
    }

    public SelenideElement getCardTextListing() {
        return cardTextListing;
    }

    public SelenideElement getCardTextInside() {
        return cardTextInside;
    }

    public SelenideElement getHoverAtStockNowInCard() {
        return hoverAtStockNowInCard;
    }

    public SelenideElement getButtonPaginator() {
        return buttonPaginator;
    }



    public void hoverDalnVostCheck() {
        int randomHover = random.nextInt(titleCollection.size());
        if (randomHover==0) {
            titleCollection.get(randomHover).click();
            dalnVostCardIfElse();
        }
        if (randomHover>=1) {
            getCardTitleOne().scrollTo();
            titleCollection.get(randomHover).click();
            dalnVostCardIfElse();
        }
    }

    public void dalnVostCardIfElse() {
        hoverAtStockNowInCard.hover();
        if (($("[class=\"search-result__state\"]").$(byText("На складе уже сейчас"))).getText().contains("Дальневосточный")) {
            getAddToBasketFromCard().click();
            Selenide.back();
        } else {
            Selenide.back();
        }
    }



}
//
//    public boolean dalnVostochCheckInsideCard() {
//        hoverAtStockNowInCard.hover();
//        $("[class='__react_component_tooltip show place-bottom type-dark tooltip']").shouldHave(Condition.text("Дальневосточный"));
//        return true;
//    }
//    public boolean dalnVostochInsideCardDoesnotExist() {
//        hoverAtStockNowInCard.hover();
//        $("[class='__react_component_tooltip show place-bottom type-dark tooltip']").shouldNotHave(Condition.text("Дальневосточный"));
//        return false;
//    }


//    public void dalnVostochCheckInsideCard() {
//        hoverAtStockNowInCard.hover();
//        ElementsCollection collectionSpan = $$("[data-id='tooltip'] li>span");
//        collectionSpan
//                .filter(Condition.text("Студенческая"))
//                .shouldHaveSize(1)
//                .first();

// FileWriter fileWriter = new FileWriter(new File("C:/fileName.txt"));

//  fileWriter.append("dasdasdas");
//    .shouldHave(Condition.text("Студенческая"));
//   $("[data-id='tooltip'] li>span").shouldHave(Condition.text("Студенческая"));

//    public void buttonAddBasCollectionClick() {
//        //        int ranNumberBasket = (int) (Math.random() * buttonAddBasCollection.size() - 1);
//        int ranNumberBasket = random.nextInt(buttonAddBasCollection.size());
//        SelenideElement selenideElement = buttonAddBasCollection.get(ranNumberBasket);
//        cardTitle.scrollTo();
//
//        selenideElement.click();
//    }


//    public void basketNumberButtonClick() {
//
//        SelenideElement selenideElement = titleCollection.get(0);
//        selenideElement.click();
//        dalnVostochCheckInsideListing();
//
//        Selenide.back();
//



