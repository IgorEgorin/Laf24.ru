package ru.laf24.test;

import com.codeborne.selenide.Selenide;
import com.codeborne.selenide.SelenideElement;
import org.openqa.selenium.By;

public class FewBrandWasFound {

    private final SelenideElement table;

    public FewBrandWasFound() {
        this.table = Selenide.$(By.tagName("table"));
    }

    public SelenideElement getTable() {
        return table;
    }
}
