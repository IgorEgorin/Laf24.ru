package ru.laf24.test;

import com.codeborne.selenide.Selenide;
import com.codeborne.selenide.SelenideElement;

import static com.codeborne.selenide.Selectors.byText;

public class DropDownCatalogGoods {

    Header h = new Header();

    private SelenideElement linkOil;
    private SelenideElement linkBrake;
    private SelenideElement linkBatteries;
    private SelenideElement linkWipers;

    public DropDownCatalogGoods() {
        this.linkOil = Selenide.$("[href='/catalog/oils']");
        this.linkBrake = Selenide.$("[href='/catalog/fluid/brake']");
        this.linkBatteries = Selenide.$(byText("Аккумуляторы"));
        this.linkWipers = Selenide.$("[href='/catalog/wipers']");
    }

    public SelenideElement getLinkOil() {
        return linkOil;
    }

    public SelenideElement getLinkBrake() {
        return linkBrake;
    }

    public SelenideElement getLinkBatteries() {
        return linkBatteries;
    }

    public SelenideElement getLinkWipers() {
        return linkWipers;
    }

    public void goToOils() {
        h.getLinkCatalogGoods().click();
        getLinkOil().click();
    }
}
