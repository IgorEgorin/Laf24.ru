package ru.laf24.test;

import com.codeborne.selenide.Selenide;
import com.codeborne.selenide.SelenideElement;

import static com.codeborne.selenide.Selectors.byText;

public class CarsForeign {

    private final SelenideElement brandFord;
    private final SelenideElement modelFordFocus;
    private final SelenideElement generationFocusII2004HatchbackDa;
    private final SelenideElement engineFocusII2004HatchbackDa100HpHwda;

    private final SelenideElement brandMitsubishi;
    private final SelenideElement modelMitsubishiLancer;
    private final SelenideElement generationMitsubishiLancerEX2007Cyza;
    private final SelenideElement engineMitsubishiLancerEX2007Cyza117HP4A92;

    private final SelenideElement brandKia;
    private final SelenideElement modelKiaCeed;
    private final SelenideElement generationKiaCeedEd2006Hatchback;
    private final SelenideElement engineKiaCeedEd2006Hatchback115HpG4fc;

    private final SelenideElement inputFullCatalog;

    private final SelenideElement openFullCatalog;

    private final SelenideElement linkDropDownBrake;
    private final SelenideElement linkDropDownIgnition;
    private final SelenideElement linkDropDownFilter;
    private final SelenideElement linkDropDownSuspensionAbsorber;
    private final SelenideElement linkDropDownSuspensionAxle;
    private final SelenideElement linkDropDownKnuckleCar;
    private final SelenideElement linkDropDownBelt;
    private final SelenideElement linkDropDownGeneratorBelt;
    private final SelenideElement linkDropDownSteering;
    private final SelenideElement linkDropDownStabilizator;
    private final SelenideElement linkDropDownCoolSystem;
    private final SelenideElement linkDropDownTermostat;

    private final SelenideElement linkDiscBrakeMechanism;
    private final SelenideElement linkBrakePads;
    private final SelenideElement linkIngnitionPlugs;
    private final SelenideElement linkFuelFilter;
    private final SelenideElement linkBearing;
    private final SelenideElement linkGeneratorBelt;
    private final SelenideElement linkTieRodEnd;
    private final SelenideElement linkStabilizatorLink;
    private final SelenideElement linkAirFilter;
    private final SelenideElement linkTermostat;
    private final SelenideElement linkShockAbsorber;
    private final SelenideElement linkSuspensionSpring;

    public CarsForeign() {
        this.brandFord = Selenide.$("[href='/cars/ford']");
        this.modelFordFocus = Selenide.$("[href='/cars/ford/focus']");
        this.generationFocusII2004HatchbackDa = Selenide.$("[href='/cars/ford/focus/focus_ii_da']");
        this.engineFocusII2004HatchbackDa100HpHwda = Selenide.$("[href='/cars/ford/focus/focus_ii_da/1_6_hwda_hwdb_shda_shdb_shdc_100_l_s_benzin']");
        this.brandMitsubishi = Selenide.$("[href='/cars/mitsubishi']");
        this.modelMitsubishiLancer = Selenide.$("[href='/cars/mitsubishi/lancer']");
        this.generationMitsubishiLancerEX2007Cyza = Selenide.$("[href='/cars/mitsubishi/lancer/lancer_ex_sedan_cy_za']");
        this.engineMitsubishiLancerEX2007Cyza117HP4A92 = Selenide.$("[href='/cars/mitsubishi/lancer/lancer_ex_sedan_cy_za/1_6_4a92_117_l_s_benzin']");
        this.brandKia = Selenide.$("[href='/cars/kia']");
        this.modelKiaCeed = Selenide.$("[href='/cars/kia/ceed']");
        this.generationKiaCeedEd2006Hatchback = Selenide.$("[href='/cars/kia/ceed/ceed_naklonnaya_zadnyaya_chast_ed']");
        this.engineKiaCeedEd2006Hatchback115HpG4fc = Selenide.$("[href='/cars/kia/ceed/ceed_naklonnaya_zadnyaya_chast_ed/1_6_g4fc_115_l_s_benzin']");
        this.inputFullCatalog = Selenide.$("#search-form__main");
        this.openFullCatalog = Selenide.$(".menu_ico");
        this.linkDropDownBrake = Selenide.$(byText("тормозная система"));
        this.linkDropDownIgnition = Selenide.$(byText("Система зажигания / накаливания"));
        this.linkDropDownFilter = Selenide.$(byText("фильтр"));
        this.linkDropDownSuspensionAbsorber = Selenide.$(byText("Подвеска / амортизация"));
        this.linkDropDownSuspensionAxle = Selenide.$(byText("Подвеска оси / система подвески / колеса"));
        this.linkDropDownKnuckleCar = Selenide.$(byText("Ступица колеса / установка"));
        this.linkDropDownBelt = Selenide.$(byText("Ременный привод"));
        this.linkDropDownGeneratorBelt = Selenide.$(byText("Поликлиновой ремень / комплект"));
        this.linkDropDownSteering = Selenide.$(byText("рулевое управления"));
        this.linkDropDownStabilizator = Selenide.$(byText("Стабилизатор / детали крепежа"));
        this.linkDropDownCoolSystem = Selenide.$(byText("Система охлаждения"));
        this.linkDropDownTermostat = Selenide.$(byText("Термостат / прокладка"));
        this.linkDiscBrakeMechanism = Selenide.$(byText("Дисковой тормозной механизм"));
        this.linkBrakePads = Selenide.$(byText("Тормозные колодки"));
        this.linkIngnitionPlugs = Selenide.$(byText("Свеча зажигания"));
        this.linkFuelFilter = Selenide.$(byText("Топливный фильтр"));
        this.linkBearing = Selenide.$(byText("Подшипник ступицы колеса"));
        this.linkGeneratorBelt = Selenide.$(byText("Поликлиновый ремень"));
        this.linkTieRodEnd = Selenide.$(byText("Шарниры"));
        this.linkStabilizatorLink = Selenide.$(byText("Стойка стабилизатора"));
        this.linkAirFilter = Selenide.$(byText("Воздушный фильтр"));
        this.linkTermostat = Selenide.$(byText("Термостат"));
        this.linkShockAbsorber = Selenide.$(byText("Амортизатор"));
        this.linkSuspensionSpring = Selenide.$(byText("Подвеска"));
    }

    public SelenideElement getBrandFord() {
        return brandFord;
    }

    public SelenideElement getModelFordFocus() {
        return modelFordFocus;
    }

    public SelenideElement getGenerationFocusII2004HatchbackDa() {
        return generationFocusII2004HatchbackDa;
    }

    public SelenideElement getEngineFocusII2004HatchbackDa100HpHwda() {
        return engineFocusII2004HatchbackDa100HpHwda;
    }

    public SelenideElement getBrandMitsubishi() {
        return brandMitsubishi;
    }

    public SelenideElement getModelMitsubishiLancer() {
        return modelMitsubishiLancer;
    }

    public SelenideElement getGenerationMitsubishiLancerEX2007Cyza() {
        return generationMitsubishiLancerEX2007Cyza;
    }

    public SelenideElement getEngineMitsubishiLancerEX2007Cyza117HP4A92() {
        return engineMitsubishiLancerEX2007Cyza117HP4A92;
    }

    public SelenideElement getBrandKia() {
        return brandKia;
    }

    public SelenideElement getModelKiaCeed() {
        return modelKiaCeed;
    }

    public SelenideElement getGenerationKiaCeedEd2006Hatchback() {
        return generationKiaCeedEd2006Hatchback;
    }

    public SelenideElement getEngineKiaCeedEd2006Hatchback115HpG4fc() {
        return engineKiaCeedEd2006Hatchback115HpG4fc;
    }

    public SelenideElement getInputFullCatalog() {
        return inputFullCatalog;
    }

    public SelenideElement getOpenFullCatalog() {
        return openFullCatalog;
    }

    public SelenideElement getLinkDropDownBrake() {
        return linkDropDownBrake;
    }

    public SelenideElement getLinkDropDownIgnition() {
        return linkDropDownIgnition;
    }

    public SelenideElement getLinkDropDownFilter() {
        return linkDropDownFilter;
    }

    public SelenideElement getLinkDropDownSuspension() {
        return linkDropDownSuspensionAbsorber;
    }

    public SelenideElement getLinkDropDownSuspensionAxle() {
        return linkDropDownSuspensionAxle;
    }

    public SelenideElement getLinkDropDownKnuckleCar() {
        return linkDropDownKnuckleCar;
    }

    public SelenideElement getLinkDropDownBelt() {
        return linkDropDownBelt;
    }

    public SelenideElement getLinkDropDownGeneratorBelt() {
        return linkDropDownGeneratorBelt;
    }

    public SelenideElement getLinkDropDownSteering() {
        return linkDropDownSteering;
    }

    public SelenideElement getLinkDropDownStabilizator() {
        return linkDropDownStabilizator;
    }

    public SelenideElement getLinkDropDownCoolSystem() {
        return linkDropDownCoolSystem;
    }

    public SelenideElement getLinkDropDownTermostat() {
        return linkDropDownTermostat;
    }

    public SelenideElement getLinkDiscBrakeMechanism() {
        return linkDiscBrakeMechanism;
    }

    public SelenideElement getLinkBrakePads() {
        return linkBrakePads;
    }

    public SelenideElement getLinkIngnitionPlugs() {
        return linkIngnitionPlugs;
    }

    public SelenideElement getLinkFuelFilter() {
        return linkFuelFilter;
    }

    public SelenideElement getLinkBearing() {
        return linkBearing;
    }

    public SelenideElement getLinkGeneratorBelt() {
        return linkGeneratorBelt;
    }

    public SelenideElement getLinkTieRodEnd() {
        return linkTieRodEnd;
    }

    public SelenideElement getLinkStabilizatorLink() {
        return linkStabilizatorLink;
    }

    public SelenideElement getLinkAirFilter() {
        return linkAirFilter;
    }

    public SelenideElement getLinkTermostat() {
        return linkTermostat;
    }

    public SelenideElement getLinkShockAbsorber() {
        return linkShockAbsorber;
    }

    public SelenideElement getLinkSuspensionSpring() {
        return linkSuspensionSpring;
    }


}
