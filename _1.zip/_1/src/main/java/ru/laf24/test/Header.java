package ru.laf24.test;

import com.codeborne.selenide.Selenide;
import com.codeborne.selenide.SelenideElement;

import static com.codeborne.selenide.Selectors.byText;

public class Header {


    private SelenideElement footer;
    private SelenideElement linkCitySpb;
    private SelenideElement linkCityPetrozavodsk;
    private SelenideElement linkCityPskov;
    private SelenideElement linkCityVelNovgorod;
    private SelenideElement linkCityAnotherCity;
    private SelenideElement linkCityInHeader;
    private SelenideElement linkSearchByCar;
    private SelenideElement buttonSearchField;
    private SelenideElement footerSearchField;
    private SelenideElement buttonLogIn;
    private SelenideElement fioInHeader;
    private SelenideElement buttonCallMe;
    private SelenideElement buttonHeaderBasket;
    private SelenideElement linkCatalogGoods;
    private SelenideElement linkHelp;


    public Header() {
        this.footer = Selenide.$(".main-header");
        this.linkCitySpb = footer.$(byText(CitiesHeader.Spb.getCityText()));
        this.linkCityPetrozavodsk = footer.$(byText(CitiesHeader.Petrozavodsk.getCityText()));
        this.linkCityPskov = footer.$(byText(CitiesHeader.Pskov.getCityText()));
        this.linkCityVelNovgorod = footer.$(byText(CitiesHeader.VelNovgorod.getCityText()));
        this.linkCityAnotherCity = footer.$(byText(CitiesHeader.AnotherCity.getCityText()));
        this.linkCityInHeader = footer.$("[class='header-top__info-place__block block_city-change']");
        this.linkSearchByCar = footer.$("[href='/cars']");
        this.footerSearchField = footer.$("input.input-field__val");
        this.buttonLogIn = footer.$(".block-login");
        this.fioInHeader = footer.$(".name-link block-login");
        this.buttonCallMe = footer.$(".block-phone__link");
        this.buttonHeaderBasket = footer.$("[class='header__basket__counter show']");
        this.linkCatalogGoods = footer.$(byText("Каталог товаров"));
        this.linkHelp = footer.$("[href='/client']");
    }

    public SelenideElement getFooterSearchField(String number) {
        this.footerSearchField.sendKeys(number);
        this.buttonSearchField.click();
        return footerSearchField;
    }

    public SelenideElement getLinkCitySpb() {
        return linkCitySpb;
    }

    public SelenideElement getLinkCityPetrozavodsk() {
        return linkCityPetrozavodsk;
    }

    public SelenideElement getLinkCityPskov() {
        return linkCityPskov;
    }

    public SelenideElement getLinkCityVelNovgorod() {
        return linkCityVelNovgorod;
    }

    public SelenideElement getLinkCityAnotherCity() {
        return linkCityAnotherCity;
    }

    public SelenideElement getLinkCityInHeader() {
        return linkCityInHeader;
    }

    public SelenideElement getLinkSearchByCar() {
        return linkSearchByCar;
    }

    public SelenideElement getButtonLogIn() {
        return buttonLogIn;
    }

    public SelenideElement getFioInHeader(String Fio) {

        return fioInHeader;
    }

    public SelenideElement getButtonCallMe() {
        return buttonCallMe;
    }

    public SelenideElement getButtonHeaderBasket() {
        return buttonHeaderBasket;
    }

    public SelenideElement getLinkCatalogGoods() {
        return linkCatalogGoods;
    }

    public SelenideElement getLinkHelp() {
        return linkHelp;
    }

    public enum CitiesHeader {
        Spb("Санкт-Петербург"),
        Petrozavodsk("Петрозаводск"),
        Pskov("Псков"),
        VelNovgorod("Великий Новгород"),
        AnotherCity("Другой город"),;

        private String cityText;

        CitiesHeader(String cityText) {
            this.cityText = cityText;
        }

        public String getCityText() {
            return cityText;
        }
    }

    public SelenideElement getCityLink(CitiesHeader citiesSwitch) {
        switch (citiesSwitch) {
            case Spb:
                return linkCitySpb;
            case Petrozavodsk:
                return linkCityPetrozavodsk;
            case Pskov:
                return linkCityPskov;
            case VelNovgorod:
                return linkCityVelNovgorod;
            case AnotherCity:
                return linkCityAnotherCity;
        }
        return null;
    }
}
