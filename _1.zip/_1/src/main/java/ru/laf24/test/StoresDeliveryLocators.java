package ru.laf24.test;

import com.codeborne.selenide.Selenide;
import com.codeborne.selenide.SelenideElement;

import static com.codeborne.selenide.Selectors.byText;


public class StoresDeliveryLocators {

    private final SelenideElement e;
    private final SelenideElement storeDalnevostochniy;
    private final SelenideElement takeOrderHere;

    public StoresDeliveryLocators() {
        this.e = Selenide.$(".delivery-type__section");
        this.storeDalnevostochniy = e.$("label[for='store_12769']");
        this.takeOrderHere = e.$(byText("Заберу отсюда"));
    }

    public SelenideElement getStoreDalnevostochniy() {
        return storeDalnevostochniy;
    }
}
