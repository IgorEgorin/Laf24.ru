package ru.laf24.test;

/**
 * Created by 1 on 26.01.2018.
 */
public class ReCallData {

    public String name;
    public String phone;
    public String vin;
    public String question;

    public ReCallData(String name, String phone, String vin, String question) {
        this.name = name;
        this.phone = phone;
        this.vin = vin;
        this.question = question;
    }

    @Override
    public String toString() {
        return name+vin+phone+question;
    }
}
