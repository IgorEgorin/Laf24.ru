package ru.laf24.test;

import com.codeborne.selenide.Selenide;
import com.codeborne.selenide.SelenideElement;

import static com.codeborne.selenide.Selenide.$;

public class MessageCallBackLocators {

    private final SelenideElement e;
    private final SelenideElement nameFieldCallBack;
    private final SelenideElement phoneFieldCallBack;
    private final SelenideElement vinFieldCallBack;
    private final SelenideElement questionFieldCallBack;

    public MessageCallBackLocators() {
        this.e = $("[class='callback__form']");
        this.nameFieldCallBack = $("[class='callback__form'] [for='name']");
        this.vinFieldCallBack = e.$("[for='vin']");
        this.phoneFieldCallBack = e.$("[for='phone']");
        this.questionFieldCallBack = e.$("[for='question']");
    }

    public SelenideElement getNameFieldCallBack() {
        return nameFieldCallBack;
    }

    public SelenideElement getVinFieldCallBack() {
        return vinFieldCallBack;
    }

    public SelenideElement getPhoneFieldCallBack() {
        return phoneFieldCallBack;
    }

    public SelenideElement getQuestionFieldCallBack() {
        return questionFieldCallBack;
    }

    public MessageCallBackLocators enterTextCallBackByArrayList(String nameFieldCallBack, String vinFieldCallBack, String questionFieldCallBack) {
        getNameFieldCallBack().sendKeys(nameFieldCallBack);
        getVinFieldCallBack().sendKeys(vinFieldCallBack);
        getQuestionFieldCallBack().sendKeys(questionFieldCallBack);
        return new MessageCallBackLocators();
    }

    public MessageCallBackLocators textFourParameters(String name, String phone, String vin, String question) {
        getNameFieldCallBack().sendKeys((name));
        getPhoneFieldCallBack().sendKeys(phone);
        getVinFieldCallBack().sendKeys(vin);
        getQuestionFieldCallBack().sendKeys(question);
        return new MessageCallBackLocators();
    }


}
