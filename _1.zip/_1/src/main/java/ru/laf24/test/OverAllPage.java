package ru.laf24.test;

public class OverAllPage {

    public Header header = new Header();
    public DropDownCatalogGoods catalogGoods = new DropDownCatalogGoods();
    public FiltersInListing filtersInListing = new FiltersInListing();
    public Listing listing = new Listing();
    public BasketPage basketPage = new BasketPage();

    private final Header headerLocators;
    private final LogInPopUp logInPopUp;


    public OverAllPage() {
        this.headerLocators = new Header();
        this.logInPopUp = new LogInPopUp();
    }

    public Header getHeaderLocators() {
        return headerLocators;
    }

    public LogInPopUp getLogInPopUp() {
        return logInPopUp;
    }
}
