package ru.laf24.test;

import com.codeborne.selenide.SelenideElement;
import org.openqa.selenium.By;

import static com.codeborne.selenide.Selenide.$;

public class LogInPopUp {

    private SelenideElement element;

    private SelenideElement switchLogInSystem;
    private SelenideElement logInPhoneField;
    private SelenideElement logInPasswordField;
    private SelenideElement logInLinkForgetPassword;
    private SelenideElement logInFormSubmit;
    private SelenideElement switchQuickRegistration;
    private SelenideElement quickRegFioField;
    private SelenideElement quickRegPhoneField;
    private SelenideElement quickRegMailField;
    private SelenideElement quickRegForB2B;
    private SelenideElement quickRegSubmit;

    public LogInPopUp() {
        this.element = $("[class='login-wrap false']");
        this.switchLogInSystem =
        this.logInPhoneField =  element.$("input[type='text']");
        this.logInPasswordField = element.$("input[type='password']");
        this.logInLinkForgetPassword = logInLinkForgetPassword;
        this.logInFormSubmit = element.$(By.tagName("button"));
        this.switchQuickRegistration = switchQuickRegistration;
        this.quickRegFioField = quickRegFioField;
        this.quickRegPhoneField = quickRegPhoneField;
        this.quickRegMailField = quickRegMailField;
        this.quickRegForB2B = quickRegForB2B;
        this.quickRegSubmit = quickRegSubmit;
    }

    public SelenideElement getElement() {
        return element;
    }

    public SelenideElement getSwitchLogInSystem() {
        return switchLogInSystem;
    }

    public SelenideElement getLogInPhoneField() {
        return logInPhoneField;
    }

    public SelenideElement getLogInPasswordField() {
        return logInPasswordField;
    }

    public SelenideElement getLogInLinkForgetPassword() {
        return logInLinkForgetPassword;
    }

    public SelenideElement getLogInFormSubmit() {
        return logInFormSubmit;
    }

    public SelenideElement getSwitchQuickRegistration() {
        return switchQuickRegistration;
    }

    public SelenideElement getQuickRegFioField() {
        return quickRegFioField;
    }

    public SelenideElement getQuickRegPhoneField() {
        return quickRegPhoneField;
    }

    public SelenideElement getQuickRegMailField() {
        return quickRegMailField;
    }

    public SelenideElement getQuickRegForB2B() {
        return quickRegForB2B;
    }

    public SelenideElement getQuickRegSubmit() {
        return quickRegSubmit;
    }


    public void doLogAsclient() {
        new Header().getButtonLogIn().click();
        getLogInPhoneField().sendKeys("7agera@gmail.com");
        getLogInPasswordField().sendKeys("90455197aa");
        getLogInFormSubmit().click();
    }

    public void doLogAsManagerAndClient() {
        new Header().getButtonLogIn().click();
        getLogInPhoneField().sendKeys("9999999593a@gmail.com");
        getLogInPasswordField().sendKeys("90455197");
        getLogInFormSubmit().click();
    }
}
