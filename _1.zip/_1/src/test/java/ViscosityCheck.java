import com.codeborne.selenide.Condition;
import com.codeborne.selenide.Selenide;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import ru.laf24.test.FiltersInListing;
import ru.laf24.test.Listing;
import ru.laf24.test.PrecondChrome;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;

import static com.codeborne.selenide.Selectors.byText;
import static com.codeborne.selenide.Selenide.$;

/**
 * Created by 1 on 18.01.2018.
 */
@RunWith(Parameterized.class)
public class ViscosityCheck extends PrecondChrome{

    private final FiltersInListing filtersInListing = new FiltersInListing();
    private final Listing listing = new Listing();

    @Parameterized.Parameter
    public String string;

    @Parameterized.Parameters(name = "{0}")
    public static List<String> data()throws IOException {
        List<String> files = Files.readAllLines(Paths.get("src\\main\\resources\\ViscosityText.txt"), StandardCharsets.UTF_8);
        return files;
    }

    @Test
    public void checkViscocity() {
        filtersInListing.getViscocitySeries().click();
        $("[class='filter indent-20']").$(byText(string)).click();
        listing.getCardTitleOne().click();
        listing.getCardTextInside().shouldHave(Condition.text(string));
//        if (!$(byText(string)).is(Condition.visible)) {
//            Selenide.back();
//        }
//        Selenide.back();
    }
}
