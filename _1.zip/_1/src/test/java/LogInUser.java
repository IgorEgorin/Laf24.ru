import org.junit.Test;
import ru.laf24.test.LogInPopUp;
import ru.laf24.test.PrecondChrome;

import static com.codeborne.selenide.Selenide.sleep;

public class LogInUser extends PrecondChrome {


    @Test
    public void logInClient() {
        new LogInPopUp().doLogAsclient();

        sleep(3000);

    }

    @Test
    public void logInManager() {
        new LogInPopUp().doLogAsManagerAndClient();
    }
}
