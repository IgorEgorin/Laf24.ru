import com.codeborne.selenide.Condition;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import ru.laf24.test.FiltersInListing;
import ru.laf24.test.Listing;
import ru.laf24.test.PrecondChrome;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;

import static com.codeborne.selenide.Selectors.byText;
import static com.codeborne.selenide.Selenide.$;

@RunWith(Parameterized.class)
public class TxtOilCheck extends PrecondChrome{

    private final FiltersInListing filtersInListing = new FiltersInListing();
    private final Listing listing = new Listing();

    @Parameterized.Parameter
    public String brandOil;

    @Parameterized.Parameters(name = "{0}")
    public static List<String> data() throws IOException {
        List<String> txtFile = Files.readAllLines(Paths.get("src\\main\\resources\\OilBrandFromFilter.txt"), StandardCharsets.UTF_8);

        return txtFile;
    }

    @Test
    public void checkBrandTxt() {
        filtersInListing.getFilterBrand().click();
        if (filtersInListing.getFilterBrandShowAll().is(Condition.visible)) {
            filtersInListing.getFilterBrandShowAll().click();
        }
        $("[class=\"filter indent-20\"]").$(byText(brandOil)).click();
        $(listing.getCardTitleOne()).shouldHave(Condition.text(brandOil));
        $("[class=\"chip__close\"]").click();

    }
}
