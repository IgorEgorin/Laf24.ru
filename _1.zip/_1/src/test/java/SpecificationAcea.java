import com.codeborne.selenide.Condition;
import com.codeborne.selenide.Selenide;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import ru.laf24.test.FiltersInListing;
import ru.laf24.test.Listing;
import ru.laf24.test.PrecondChrome;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;

import static com.codeborne.selenide.Selectors.byText;
import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.sleep;
import static java.nio.charset.StandardCharsets.UTF_8;

/**
 * Created by 1 on 21.01.2018.
 */
@RunWith(Parameterized.class)
public class SpecificationAcea extends PrecondChrome{

    private final FiltersInListing filtersInListing = new FiltersInListing();
    private final Listing listing = new Listing();

    @Parameterized.Parameter
    public String string;

    @Parameterized.Parameters
    public static List<String> data() throws IOException {
        List<String> files = Files.readAllLines(Paths.get("src\\main\\resources\\SpecificationAcea.txt"), StandardCharsets.UTF_8);
        return files;
    }



    @Test
    public void checkAcea() throws Exception {
        filtersInListing.getFilterSpecificationAcea().click();
        filtersInListing.getFilterSpecAceaDropDown().click();
        $("[class=\"dropdown-content select-dropdown multiple-select-dropdown active\"]").$(byText(string)).click();
        listing.getCardTitleOne().scrollTo();
        listing.getCardTitleOne().click();
        listing.getCardTextInside().shouldHave(Condition.text(string));
        Selenide.back();
        filtersInListing.getChipsClose().click();


    }
}
