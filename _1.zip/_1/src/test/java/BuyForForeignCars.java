import org.junit.Test;
import ru.laf24.test.CarsForeign;
import ru.laf24.test.Header;
import ru.laf24.test.Listing;
import ru.laf24.test.PrecondChrome;

import static com.codeborne.selenide.Selenide.sleep;

public class BuyForForeignCars extends PrecondChrome {

    private CarsForeign carsF = new CarsForeign();
    private Listing listingL = new Listing();

    @Test
    public void PartsFocus2() {
        redirectForeignCars();
        carsF.getBrandFord().click();
        carsF.getModelFordFocus().click();
        carsF.getGenerationFocusII2004HatchbackDa().click();
        carsF.getEngineFocusII2004HatchbackDa100HpHwda().click();
        addPadsBasket();
        addIgnitionPlugsBasket();
        addFuelFilterBasket();

        sleep(4000);

    }

    @Test
    public void partsLancer2007() {
        redirectForeignCars();
        carsF.getBrandMitsubishi().click();
        carsF.getModelMitsubishiLancer().click();
        carsF.getGenerationMitsubishiLancerEX2007Cyza().click();
        carsF.getEngineMitsubishiLancerEX2007Cyza117HP4A92().click();
        addIgnitionPlugsBasket();
        addBearingbasket();
        addGeneratorBeltBasket();
        addTieRodEndBasket();
        addStabBasket();

        sleep(4000);
    }

    @Test
    public void partsCeed2006() {
        carsF.getBrandKia().click();
        carsF.getModelKiaCeed().click();
        carsF.getGenerationKiaCeedEd2006Hatchback().click();
        carsF.getEngineKiaCeedEd2006Hatchback115HpG4fc().click();
        addAirFilterBasket();
        addTermostatBasket();
        addShockAbsorberBasket();
        addSpringBasket();


        sleep(4000);
    }

    private void addSpringBasket() {
        openCatalog();
        carsF.getLinkDropDownSuspension().click();
        carsF.getLinkSuspensionSpring().click();
        addBasMeth();
    }

    private void addShockAbsorberBasket() {
        openCatalog();
        carsF.getLinkDropDownSuspension().click();
        carsF.getLinkShockAbsorber().click();
        addBasMeth();
    }

    private void addTermostatBasket() {
        openCatalog();
        carsF.getLinkDropDownCoolSystem().click();
        carsF.getLinkDropDownTermostat().click();
        carsF.getLinkTermostat().click();
        addBasMeth();
    }

    private void addAirFilterBasket() {
        openCatalog();
        carsF.getLinkDropDownFilter().click();
        carsF.getLinkAirFilter().click();
        addBasMeth();
    }


    private void addStabBasket() {
        openCatalog();
        carsF.getLinkDropDownSuspensionAxle().click();
        carsF.getLinkDropDownStabilizator().click();
        carsF.getLinkStabilizatorLink().click();
        addBasMeth();
    }

    private void addTieRodEndBasket() {
        openCatalog();
        carsF.getLinkDropDownSteering().click();
        carsF.getLinkTieRodEnd().click();
        addBasMeth();
    }

    private void addGeneratorBeltBasket() {
        openCatalog();
        carsF.getLinkDropDownBelt().click();
        carsF.getLinkDropDownGeneratorBelt().click();
        carsF.getLinkGeneratorBelt().click();
        listingL.getAddToBasket().click();
    }

    private void addBearingbasket() {
        openCatalog();
        carsF.getLinkDropDownSuspensionAxle().click();
        carsF.getLinkDropDownKnuckleCar().click();
        carsF.getLinkBearing().click();
        listingL.getAddToBasket().click();
    }

    private void redirectForeignCars() {
        new Header().getLinkSearchByCar().click();
    }

    private void addFuelFilterBasket() {
        openCatalog();
        carsF.getLinkDropDownFilter().click();
        carsF.getLinkFuelFilter().click();
        addBasMeth();
    }

    public void addPadsBasket() {
        openCatalog();
        carsF.getLinkDropDownBrake().click();
        carsF.getLinkDiscBrakeMechanism().click();
        carsF.getLinkBrakePads().click();
        addBasMeth();
    }
    public void addIgnitionPlugsBasket() {
        openCatalog();
        carsF.getLinkDropDownIgnition().click();
        carsF.getLinkIngnitionPlugs().click();
        addBasMeth();
    }

    public void openCatalog() {
        carsF.getOpenFullCatalog().click();
    }

    public void addBasMeth() {
        listingL.getAddToBasket().click();
    }


}
