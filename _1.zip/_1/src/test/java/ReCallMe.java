import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import ru.laf24.test.Header;
import ru.laf24.test.MessageCallBackLocators;
import ru.laf24.test.PrecondChrome;
import ru.laf24.test.ReCallData;

import java.util.ArrayList;
import java.util.List;

import static com.codeborne.selenide.Selenide.$;

/**
 * Created by 1 on 24.01.2018.
 */
@RunWith(Parameterized.class)
public class ReCallMe extends PrecondChrome{

    public String name;
    public String phone;
    public String vin;
    public String question;

    public ReCallMe(ReCallData reCallData) {
        this.name = reCallData.name;
        this.phone = reCallData.phone;
        this.vin = reCallData.vin;
        this.question = reCallData.question;
    }

    @Parameterized.Parameters(name = "{index} {0}")
    public static List<ReCallData> data() {
        List<ReCallData> reCallDatas = new ArrayList<>();
        reCallDatas.add(new ReCallData("igor", "+7908","kkll","hello"));
        reCallDatas.add(new ReCallData("vasya", "+79880","hh","buy"));
        reCallDatas.add(new ReCallData("vova", "+6655","jj","begin"));
        reCallDatas.add(new ReCallData("vovan", "+6644","jkkkkjj","less"));
        reCallDatas.add(new ReCallData("vetal", "+6655ff","jkjj","may be"));
        reCallDatas.add(new ReCallData("anechka", "+2223","kkkkk","magnificent"));
        return reCallDatas;
    }

    @Ignore
    @Test
    public void reCallTest() throws Exception {
        header.getButtonCallMe().click();
        new MessageCallBackLocators().textFourParameters(name,phone,vin,question);

    }


}
