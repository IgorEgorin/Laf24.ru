import org.junit.Test;
import ru.laf24.test.*;

import static com.codeborne.selenide.Condition.text;
import static com.codeborne.selenide.Selenide.sleep;

public class MakeAPurchase extends PrecondChrome{

    private Header header = new Header();
    private FiltersInListing filList = new FiltersInListing();
    private Listing listingL = new Listing();
    private DropDownCatalogGoods dropCatGoods = new DropDownCatalogGoods();
    private BasketPage basketPage = new BasketPage();
    private StoresDeliveryLocators storDevLoc = new StoresDeliveryLocators();


    @Test
    public void DoPurchaseAsClient(){
            new ru.laf24.test.LogInPopUp().doLogAsclient();
              selectOilCat();
              filList.getLinkMayTake().click();
              filList.selectDalnVosStore();
              addBas();
              selectWipersCat();
              filList.selectDalnVosStore();
              addBas();
              selectBattCat();
              filList.selectDalnVosStore();
              addBas();






            listingL.getPriceInCardGoods().shouldHave(text(new ru.laf24.test.Header().getButtonHeaderBasket().getText()));

        sleep(6000);
    }


    public void selectOilCat() {
        header.getLinkCatalogGoods().click();
        dropCatGoods.getLinkOil().click();
    }
    public void selectWipersCat() {
        header.getLinkCatalogGoods().click();
        dropCatGoods.getLinkWipers().click();
    }
    public void selectBattCat() {
        header.getLinkCatalogGoods().click();
        dropCatGoods.getLinkBatteries().click();
    }
    public void addBas() {
        listingL.getAddToBasket().click();
    }

}
