import com.codeborne.selenide.ElementsCollection;
import com.codeborne.selenide.SelenideElement;
import org.junit.Test;
import ru.laf24.test.FiltersInListing;
import ru.laf24.test.Listing;
import ru.laf24.test.PrecondChrome;

import static com.codeborne.selenide.Selenide.$$;
import static com.codeborne.selenide.Selenide.sleep;

public class FilterForEach extends PrecondChrome {

    FiltersInListing filtersInListing = new FiltersInListing();
    Listing listing = new Listing();
    ElementsCollection chkBoxCollBrandSecond = $$("[class=\"filter-type__inner show\"] [class=\"item\"]");
    private SelenideElement namechkBox;

    @Test
    public void oilFilterCheck() {
        filtersInListing.getFilterBrand().click();
        filtersInListing.getFilterBrandShowAll().click();
        System.out.println(chkBoxCollBrandSecond.size());
        for (SelenideElement chkBox: chkBoxCollBrandSecond){
            chkBox.click();
            sleep(8000);
//            filtersInListing.getChipsText().shouldHave(Condition.text(listing.getCardTitle().getText()));
            System.out.println(filtersInListing.getChipsClose().getText());



        }
    }

}
