import com.codeborne.selenide.Condition;
import com.codeborne.selenide.ElementsCollection;
import com.codeborne.selenide.Selenide;
import com.codeborne.selenide.SelenideElement;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.openqa.selenium.By;
import ru.laf24.test.FiltersInListing;
import ru.laf24.test.Listing;
import ru.laf24.test.PrecondChrome;

import java.util.ArrayList;
import java.util.List;

import static com.codeborne.selenide.Condition.matchesText;
import static com.codeborne.selenide.Condition.text;
import static com.codeborne.selenide.Selectors.byText;
import static com.codeborne.selenide.Selenide.*;

/**
 * Created by 1 on 20.01.2018.
 */
@RunWith(Parameterized.class)
public class Volume extends PrecondChrome{

    private final FiltersInListing filtersInListing = new FiltersInListing();
    private final Listing listing = new Listing();

    @Parameterized.Parameter
    public String string;

    @Parameterized.Parameters
    public static List<String> data() {
        List<String> lists = new ArrayList<>();
        lists.add("0...3");
//        lists.add("3,1...10");
//        lists.add("11...1000");
        return lists;
    }

    @Test
    public void checkVolume() throws Exception {
        filtersInListing.getFilterVolume().click();
        $(byText(string)).click();
        sleep(8000);
//        System.out.println(string.replaceAll("...",));
        ElementsCollection collectionCard = $$(By.xpath(".//dd[contains(text(), \" л\")]"));
        for (SelenideElement element:collectionCard
             ) {
            String peremennaya = element.getText().replaceAll(" л","");

            if (peremennaya.contains(",")) {
                peremennaya.replace(',','.');
                System.out.println(peremennaya);
            }
            System.out.println("после ифа"+peremennaya);
            double doubleNumber = Double.parseDouble(peremennaya);
            sleep(1000);
            Assert.assertTrue(doubleNumber>=0.0&&doubleNumber<=3.0);


        }


    }
}
