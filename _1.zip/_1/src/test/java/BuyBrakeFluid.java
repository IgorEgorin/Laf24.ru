import com.codeborne.selenide.Condition;
import com.codeborne.selenide.Selectors;
import com.codeborne.selenide.Selenide;
import org.junit.Test;
import org.openqa.selenium.By;
import ru.laf24.test.*;
import ru.laf24.test.PrecondChrome;

import static com.codeborne.selenide.Selectors.byText;
import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.sleep;

/**
 * Created by 1 on 06.02.2018.
 */
public class BuyBrakeFluid extends PrecondChrome {

    @Test
    public void BuyTextar() throws Exception {
        header.getLinkCatalogGoods().click();
        catalogGoods.getLinkBrake().click();
        filtersInListing.getFilterBrand().click();
        filtersInListing.getFilterBrandShowAll().click();
        $("[class='filter indent-20']").$(byText("Textar")).click();
        listing.getCardTitleOne().click();
        if ($("[class=\"item-name__brand\"]").is(Condition.text("Textar").disabled)){
            System.out.println("Textar'a нету!!");
        }
        else {
            listing.getAddToBasketFromCard().click();
            header.getButtonHeaderBasket().click();
            basketPage.getButtonIncrease().click();

        }

        sleep(8000);

    }
}
