import com.codeborne.selenide.Condition;
import com.codeborne.selenide.Selenide;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import ru.laf24.test.FiltersInListing;
import ru.laf24.test.Listing;
import ru.laf24.test.PrecondChrome;

import java.util.ArrayList;
import java.util.List;

import static com.codeborne.selenide.Selectors.byText;
import static com.codeborne.selenide.Selenide.$;

/**
 * Created by 1 on 20.01.2018.
 */
@RunWith(Parameterized.class)
public class EngineType extends PrecondChrome {

    private final FiltersInListing filtersInListing = new FiltersInListing();
    private final Listing listing = new Listing();

    @Parameterized.Parameter
    public String string;

    @Parameterized.Parameters
    public static List<String> data() {
        List<String> lists = new ArrayList<>();
        lists.add("Грузовой автомобиль");
        lists.add("Легковой автомобиль");
        lists.add("Лодка");
        lists.add("Мотоцикл");
        return lists;
    }

    @Test
    public void checkTypeEngine() throws Exception {
        filtersInListing.getFilterUsage().click();
        $(byText(string)).click();
        listing.getCardTextListing().shouldHave(Condition.text(string));
        Selenide.back();
        filtersInListing.getChipsClose().click();

    }
}
