import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import ru.laf24.test.FiltersInListing;
import ru.laf24.test.Listing;
import ru.laf24.test.PrecondChrome;
import ru.laf24.test.PriceData;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.sleep;
import static java.lang.Enum.valueOf;
import static org.openqa.selenium.Keys.CONTROL;

/**
 * Created by 1 on 25.01.2018.
 */
@RunWith(Parameterized.class)
public class Price extends PrecondChrome{

    private Listing listing = new Listing();

    public Integer priceOne;
    public Integer priceTwo;

    public Price(PriceData priceData) {
        this.priceOne = priceData.priceOne;
        this.priceTwo = priceData.priceTwo;
    }

    @Parameterized.Parameters(name = "{index} {0}")
    public static List<PriceData> data() {
        List<PriceData> files = new ArrayList<>();
        files.add(new PriceData(800, 1000));
//        files.add(new PriceData("28", "166"));
        return files;
    }



    @Test
    public void priceFirst() throws Exception {
        new FiltersInListing().getFilterPrice().click();
        new FiltersInListing().enterPriceData(priceOne,priceTwo);
        listing.getCardTitleOne().click();
        int num = Integer.parseInt($("[class=\"real-price\"]").getText().replace("руб.",""));
        if (num>=800&&num<=1000) {
            System.out.println("Test passed, iT WoRk");
        }
        else {
            System.out.println("FAaaaaailed");
        }

    }
}
