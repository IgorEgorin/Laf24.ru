import com.codeborne.selenide.Condition;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import ru.laf24.test.FiltersInListing;
import ru.laf24.test.Header;
import ru.laf24.test.Listing;
import ru.laf24.test.PrecondChrome;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import static com.codeborne.selenide.Selectors.byText;
import static com.codeborne.selenide.Selenide.$;

@RunWith(Parameterized.class)
public class AddSostav extends PrecondChrome{

    private final FiltersInListing filtersInListing = new FiltersInListing();
    private final Listing listing = new Listing();

    @Parameterized.Parameter
    public String sostav;

    @Parameterized.Parameters(name = "{0}")
    public static List<String> data() throws IOException {
        List<String> compositions = new ArrayList<>();
        compositions.add("Моторное");
        compositions.add("Трансмиссионное");
        return compositions;

    }

    @Test
    public void name() {
        new Header().getButtonCallMe().click();
        $("[class='input-field'] [for='name']").sendKeys("vVAvasvav");

    }

    @Ignore
    @Test
    public void CheckSostav() {
        filtersInListing.getFilterTypeFluid().click();
        filtersInListing.getElementfilter().$(byText(sostav)).click();
        listing.getTypeFluid().shouldHave(Condition.text(sostav));
        $("[class=\"chip__close\"]").click();
        System.out.println(listing.getTypeFluid());
    }
    @Ignore
    @Test
    public void sysOut() {
        filtersInListing.getFilterBrand().click();
        filtersInListing.getFilterBrandShowAll().click();
        System.out.println($("[class='description-fltr__item']").getText());
    }
}
