import com.codeborne.selenide.Condition;
import com.codeborne.selenide.ElementsCollection;
import com.codeborne.selenide.SelenideElement;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import ru.laf24.test.FiltersInListing;
import ru.laf24.test.PrecondChrome;

import java.util.ArrayList;
import java.util.List;

import static com.codeborne.selenide.Selenide.$$;
import static com.codeborne.selenide.Selenide.sleep;

/**
 * Created by 1 on 31.01.2018.
 */
@RunWith(Parameterized.class)
public class QuantityForEach extends PrecondChrome {

    public FiltersInListing filtersInListing = new FiltersInListing();

    public Integer quantityFor;

    public QuantityForEach(Integer integer) {
        this.quantityFor = integer;
    }

    @Parameterized.Parameters(name = "{index} {0}")


    public static List<Integer> data() {
        List<Integer> files = new ArrayList<>();
        files.add(new Integer(5));
        files.add(new Integer(4));
        files.add(new Integer(2));
        files.add(new Integer(8));
        files.add(new Integer(9));
        return files;
    }

    @Test
    public void QunForEach() throws Exception {
        filtersInListing.getFilterQuantity().hover().click();
        filtersInListing.getFilterQuantityField().setValue(String.valueOf(quantityFor));
        ElementsCollection collection = $$("[class=\"item-card__about\"] [class=initial-txt]");
        for (SelenideElement selenideElement : collection
                ) {
            if (!selenideElement.has(Condition.text(" шт"))) {
                break;
            }
            String peremennaya = selenideElement.getText().replaceAll(" шт.", "").replaceAll(" ", "");
            System.out.println("строка один" + peremennaya);
            if (peremennaya.contains(">")) {
                peremennaya = peremennaya.replaceAll(">", "");
            }
            Assert.assertTrue(quantityFor <= Integer.valueOf(peremennaya));
            System.out.println(peremennaya);
            sleep(3000);

        }
    }

}


