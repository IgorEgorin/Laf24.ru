import com.codeborne.selenide.Condition;
import org.junit.Test;
import ru.laf24.test.FiltersInListing;
import ru.laf24.test.Listing;
import ru.laf24.test.PrecondChrome;

public class HoverTest extends PrecondChrome {

    public Listing listingL = new Listing();
    public FiltersInListing filList = new FiltersInListing();

    @Test
    public void HoverCheck() {
//        filList.getLinkMayTake().click();
//        filList.selectDalnVosStore();
        listingL.getHoverAtStockNow().hover().shouldHave(Condition.text("Студенческая"));
       // sleep(8000);


    }
}

