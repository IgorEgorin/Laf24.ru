import com.codeborne.selenide.Condition;
import org.junit.Ignore;
import org.junit.Test;
import ru.laf24.test.*;

import static com.codeborne.selenide.Selectors.byText;
import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.sleep;

public class BuyForForeignCars3 extends PrecondChrome {

    private final Listing listing = new Listing();
    private final FiltersInListing filtersInListing = new FiltersInListing();
    private final Header header = new Header();
    private final BasketPage basketPage = new BasketPage();
    private final StoresDeliveryLocators deliveryPage = new StoresDeliveryLocators();


    @Test
    public void Order1() {

//    l.basketNumberButtonClick();

//        for (int i = 0; i < 5; i++) {
//           $("h1[class=\"hline\"]").scrollTo();
//            l.buttonAddBasCollectionClick();
//   [class="search-result__state"]>[data-id="tooltip"] ul li[2]
//        }


    }


    @Test
    public void Order2() {

        for (int i = 0; i < 5; i++) {
            listing.hoverDalnVostCheck();
            sleep(4000);
        }
        header.getButtonHeaderBasket().click();
        basketPage.getButtonMakeOrder().click();
        deliveryPage.getStoreDalnevostochniy().click();


        sleep(5000);
    }

    @Ignore
    @Test
    public void Order3() throws Exception {
        header.getLinkCatalogGoods().click();
        $("[href=\"/catalog/sale\"]").click();
        sleep(3000);
        listing.getCardTitleOne().click();
        $("[class=\"search-result__state\"]").$(byText("На складе уже сейчас")).hover();
        sleep(5000);
    }

    @Test
    public void Order4() throws Exception {
        listing.getCardTitleOne().click();
        $("[class=\"search-result__state\"]").$(byText("На складе уже сейчас")).hover().shouldHave(Condition.text("Шушары"));
        sleep(5000);
    }
}
