import com.codeborne.selenide.Condition;
import com.codeborne.selenide.SelenideElement;
import com.codeborne.selenide.conditions.Text;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import ru.laf24.test.FiltersInListing;
import ru.laf24.test.Listing;
import ru.laf24.test.PrecondChrome;

import java.util.ArrayList;
import java.util.List;

import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.sleep;

/**
 * Created by 1 on 29.01.2018.
 */
@RunWith(Parameterized.class)
public class Quantity extends PrecondChrome {

    public FiltersInListing filtersInListing = new FiltersInListing();
    public Listing listing = new Listing();

    public Integer quantity;

    public Quantity(Integer quantityFirst) {
        this.quantity = quantityFirst;

    }

    @Parameterized.Parameters(name = "{index} {0}")
    public static List<Integer> data(){
        List<Integer> files = new ArrayList<>();
        files.add(new Integer(2));
        files.add(new Integer(5));
        files.add(new Integer(8));
        return files;
    }

    @Test
    public void quantityTest() throws Exception {
        filtersInListing.getFilterQuantity().click();
        filtersInListing.getFilterQuantityField().setValue(String.valueOf(quantity));
        Assert.assertTrue(quantity<=Integer.valueOf($("[class=\"initial-txt\"]").getText().replaceAll(" > ","").replaceAll(" шт.","")));
        sleep(5033);
        $("[class=\"initial-txt\"]");
    $("[class=\"initial-txt\"]").shouldHave(Condition.value(String.valueOf(quantity)));


    }
    @Override
    public String toString(){
        return String.valueOf(quantity);
    }
}
