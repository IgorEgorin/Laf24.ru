import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import ru.laf24.test.FiltersInListing;
import ru.laf24.test.PrecondChrome;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;

import static com.codeborne.selenide.Selectors.byText;
import static com.codeborne.selenide.Selenide.$;
import static java.nio.charset.StandardCharsets.UTF_8;

/**
 * Created by 1 on 18.01.2018.
 */
@RunWith(Parameterized.class)
public class BrandSeries extends PrecondChrome {
    private final FiltersInListing filtersInListing = new FiltersInListing();

    @Parameterized.Parameter
    public String string;

    @Parameterized.Parameters(name = "{0}")
    public static List<String> data() throws IOException {
        List<String> files = Files.readAllLines(Paths.get("src\\main\\resources\\SeriesBrandText.txt"), StandardCharsets.UTF_8);
        return files;
    }

    @Test
    public void checkBrandSeries() {
        filtersInListing.getFilterBrandSeries().click();
        $(byText(string)).click();


    }


}
