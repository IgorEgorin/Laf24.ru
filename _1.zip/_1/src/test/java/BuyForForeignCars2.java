import com.codeborne.selenide.ElementsCollection;
import com.codeborne.selenide.Selenide;
import org.junit.Test;
import ru.laf24.test.DropDownCatalogGoods;
import ru.laf24.test.FiltersInListing;
import ru.laf24.test.Listing;
import ru.laf24.test.PrecondChrome;

import static com.codeborne.selenide.CollectionCondition.texts;

public class BuyForForeignCars2 extends PrecondChrome{

    DropDownCatalogGoods catalogGoods = new DropDownCatalogGoods();
    FiltersInListing f = new FiltersInListing();
    Listing l = new Listing();


    @Test
    public void Purchase2() {
//        catalogGoods.goToOils();
//        f.getLinkMayTake().click();
//        f.selectDalnVosStore();
//        f.selectMobil();
        l.getAddToBasket().click();
        ElementsCollection elementsCollection = Selenide.$$("[class='real-price']");
        elementsCollection.shouldHave(texts(Selenide.$("[class='header-bottom__basket']").toString()));

//        System.out.println(elementsCollection);
//        System.out.println(Selenide.$("[class='header-bottom__basket']"));


    }


}
