import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import ru.laf24.test.Header;
import ru.laf24.test.MessageCallBackData;
import ru.laf24.test.MessageCallBackLocators;
import ru.laf24.test.PrecondChrome;

import java.util.ArrayList;
import java.util.List;

@RunWith(Parameterized.class)
public class CallBackHeader extends PrecondChrome {

    public String name;
    public String vinText;
    public String questionText;

    public CallBackHeader(MessageCallBackData messageCallBackData) {
        this.name = messageCallBackData.name;
        this.vinText = messageCallBackData.vinField;
        this.questionText = messageCallBackData.questionField;
    }

    @Parameterized.Parameters(name = "{index} {0}")
    public static List<MessageCallBackData> data() {

        List<MessageCallBackData> stringText =  new ArrayList<>();
        stringText.add(new MessageCallBackData("Алекс Егоров","kL1s","Перезвоните"));
        stringText.add(new MessageCallBackData("Дима Васльев","vf4t","Just test text"));
        stringText.add(new MessageCallBackData("Олег Романов","x7sssd","Сообщение Перезвоните"));

        return stringText;
    }

    @Test
    public void writeMessageByArrayList() {
        new Header().getButtonCallMe().click();
        new MessageCallBackLocators().enterTextCallBackByArrayList(name,vinText,questionText);

    }

}
